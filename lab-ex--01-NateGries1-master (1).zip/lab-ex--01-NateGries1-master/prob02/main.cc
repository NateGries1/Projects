#include <iomanip>
#include <iostream>
using namespace std;
int main() {
  cout << "Please input meal cost: ";
  double meal_cost;
  cin >> meal_cost;
  cout << "Please input tip percentage: \n";
  double tip_percent;
  cin >> tip_percent;
  cout << "Restaurant Bill\n" << "====================\n";
  cout << fixed << setprecision(2);
  double subtotal = meal_cost;
  cout << "Subtotal: $" << meal_cost << "\n";
  double tax = meal_cost * 0.075;
  cout << "Taxes: $" << tax << "\n";
  double tip = meal_cost / 100 * tip_percent;
  cout << "Tip: $" << tip << endl;
  cout << "====================" << endl;
  double total = meal_cost + tax + tip;
  cout << "Total: $" << total;
}
